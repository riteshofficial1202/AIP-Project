const express = require('express');
const bcrypt = require('bcrypt');
const User = require('../User');

const router = express.Router();

// Signup Page
router.post('/signup', async (req, res) => {
  const { email, fullName, username, password } = req.body;

  console.log('Received signup data:', req.body); // 🔍 Log the form data

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({
      email,
      fullName,
      username,
      password: hashedPassword
    });
    console.log('User created:', user); // ✅ Confirm user creation
    res.redirect('/login');
  } catch (err) {
    console.error('Error creating user:', err); // 🔥 Show full error
    res.send('Error creating user: ' + err.message);
  }
});



// Login Page
router.get('/login', (req, res) => {
  res.render('login');
});
router.get('/signup', (req, res) => {
  res.render('signup');
});

router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (user && await bcrypt.compare(password, user.password)) {
    req.session.userId = username;
    res.redirect('/dashboard');
  } else {
    res.redirect('/login');
  }
});

// Logout
router.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

module.exports = router;
