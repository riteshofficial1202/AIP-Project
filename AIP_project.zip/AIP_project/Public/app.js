const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path'); // ✅ Needed for views path
const authRoutes = require('./routes/auth');

const app = express();

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views')); // Make sure views folder is here

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: 'supersecretkey',
  resave: false,
  saveUninitialized: false
}));

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/social_dashboard')
  .then(() => console.log('Connected to MongoDB'))
  .catch((err) => console.error('MongoDB connection error:', err));

// Redirect root to login
app.get('/', (req, res) => {
  res.redirect('/login');
});

// Auth routes
app.use('/', authRoutes);

// Dashboard
app.get('/dashboard', (req, res) => {
  if (!req.session.userId) return res.redirect('/login');
  res.render('dashboard', { username: req.session.userId });
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
